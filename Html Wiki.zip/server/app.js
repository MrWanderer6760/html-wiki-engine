const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const wikiRoutes = require('./routes/wiki');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));

// Маршруты
app.use('/api/wiki', wikiRoutes);

// Запуск сервера
app.listen(PORT, () => {
    console.log(`HTML Wiki запущен на порту ${PORT}`);
});