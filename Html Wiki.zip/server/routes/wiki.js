const express = require('express');
const router = express.Router();
const Article = require('../models/article');

// Получить статью
router.get('/:slug', async (req, res) => {
    try {
        const article = await Article.getBySlug(req.params.slug);
        if (article) {
            res.json(article);
        } else {
            res.status(404).json({ error: 'Статья не найдена' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Создать/обновить статью
router.post('/:slug', async (req, res) => {
    try {
        const { title, content } = req.body;
        const article = await Article.createOrUpdate(req.params.slug, title, content);
        res.json(article);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;