const fs = require('fs').promises;
const path = require('path');
const storagePath = path.join(__dirname, '../storage/articles');

class Article {
    static async getBySlug(slug) {
        try {
            const filePath = path.join(storagePath, `${slug}.json`);
            const data = await fs.readFile(filePath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            return null;
        }
    }

    static async createOrUpdate(slug, title, content) {
        const article = {
            slug,
            title,
            content,
            updatedAt: new Date().toISOString()
        };

        const filePath = path.join(storagePath, `${slug}.json`);
        await fs.writeFile(filePath, JSON.stringify(article, null, 2));
        return article;
    }

    static async getAll() {
        try {
            const files = await fs.readdir(storagePath);
            const articles = [];
            
            for (const file of files) {
                if (file.endsWith('.json')) {
                    const data = await fs.readFile(path.join(storagePath, file), 'utf8');
                    articles.push(JSON.parse(data));
                }
            }
            
            return articles;
        } catch (error) {
            return [];
        }
    }
}

module.exports = Article;