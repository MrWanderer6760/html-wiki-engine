document.addEventListener('DOMContentLoaded', async () => {
    // Загрузка списка статей
    const loadArticles = async () => {
        const response = await fetch('/api/wiki');
        const articles = await response.json();
        const list = document.getElementById('article-list');
        
        list.innerHTML = articles.map(article => 
            `<li><a href="#" data-slug="${article.slug}">${article.title}</a></li>`
        ).join('');
        
        // Обработчик клика по статье
        document.querySelectorAll('#article-list a').forEach(link => {
            link.addEventListener('click', async (e) => {
                e.preventDefault();
                await loadArticle(link.dataset.slug);
            });
        });
    };
    
    // Загрузка статьи
    const loadArticle = async (slug) => {
        const response = await fetch(`/api/wiki/${slug}`);
        const article = await response.json();
        
        document.getElementById('article-title').textContent = article.title;
        document.getElementById('article-content').innerHTML = article.content;
        document.getElementById('article-editor').value = article.content;
        
        // Сохраняем текущий slug для редактирования
        document.getElementById('save-btn').dataset.slug = slug;
    };
    
    // Редактирование статьи
    document.getElementById('edit-btn').addEventListener('click', () => {
        document.getElementById('article-content').style.display = 'none';
        document.getElementById('article-editor').style.display = 'block';
        document.getElementById('edit-btn').style.display = 'none';
        document.getElementById('save-btn').style.display = 'block';
    });
    
    // Сохранение статьи
    document.getElementById('save-btn').addEventListener('click', async () => {
        const slug = document.getElementById('save-btn').dataset.slug;
        const title = document.getElementById('article-title').textContent;
        const content = document.getElementById('article-editor').value;
        
        await fetch(`/api/wiki/${slug}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, content })
        });
        
        document.getElementById('article-content').innerHTML = content;
        document.getElementById('article-content').style.display = 'block';
        document.getElementById('article-editor').style.display = 'none';
        document.getElementById('edit-btn').style.display = 'block';
        document.getElementById('save-btn').style.display = 'none';
    });
    
    // Инициализация
    await loadArticles();
    await loadArticle('main-page'); // Загрузка главной страницы по умолчанию
});